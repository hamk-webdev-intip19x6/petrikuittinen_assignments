with open("testi.txt", "w") as f:
    f.write("Hello\n2nd line\n")
