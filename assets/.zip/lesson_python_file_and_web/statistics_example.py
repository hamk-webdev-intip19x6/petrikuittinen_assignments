from statistics import mean, median, mode
a = [1, 0, 3, 2, 2, 10, 5, 4, 3, 2, 6, 7]
print("Average:", mean(a))
print("Median:", median(a))
print("Most common:", mode(a))

