with open("testi.txt") as f:
    for line in f:
        print(line.rstrip())

