with open("testi.txt", "w", encoding="utf-8") as f:
    f.writelines(["Hello ÄÖ\n", "2nd line\n"])
    

