with open("testi.txt", "w", encoding="utf-8") as f:
    print("Hello ÄÖ", file=f)
    print("привет! 你好!", file=f)
    
    

