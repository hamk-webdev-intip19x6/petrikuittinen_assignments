f = open("testi.txt", "w") # open file in write (text) mode
f.write("Hello\n2nd line\n")
f.close() # don't forget to close file

