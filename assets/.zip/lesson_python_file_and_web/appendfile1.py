f = open("testi.txt", "a") # open file in append mode = add to end
f.write("one more line\n")
f.close()
