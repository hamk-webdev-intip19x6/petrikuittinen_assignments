with open("testi.txt") as f:
    print(f.read())
