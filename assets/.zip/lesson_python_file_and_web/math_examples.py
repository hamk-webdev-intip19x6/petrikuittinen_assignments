import math
x = 1234.5678
print("X rounded:", round(x))
print("X rounded down:", math.floor(x))
print("X rounded up:", math.ceil(x))
print("10 base logarithm of 2 is", math.log10(2))
print("Square root of 2 is", math.sqrt(2))
print("e to power of 2 is", math.exp(2))
print("sin(0)", math.sin(0))
print("cos(0)", math.cos(0))
print("tan(0)", math.tan(0))
print("180 degrees in radians is", math.radians(180))
print("PI in degrees is", math.degrees(math.pi))



