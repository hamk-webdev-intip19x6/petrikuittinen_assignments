with open("testi.txt", "a") as f:
    f.write("one more line\n")
