// JavaScript File
export function cmToInches(cm) {
    return cm/2.54;
}
export function inchesToCm(inch) {
    return inch*2.54;
}