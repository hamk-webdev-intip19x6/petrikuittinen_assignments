poor = True
stupid = True
healthy = False
print(poor) # True
print(not poor) # False 
print(poor and stupid) # True
print(poor and healthy) # False
print(poor or healthy) # True
