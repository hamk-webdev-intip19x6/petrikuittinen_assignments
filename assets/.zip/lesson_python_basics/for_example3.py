# range(begin, end, step)
# for iterates through a sequence
# 10..1
names = ["Jack", "Bob", "Bill", "Alice", "Jane", "Liza"]

for name in names:
    print(name)
    
    