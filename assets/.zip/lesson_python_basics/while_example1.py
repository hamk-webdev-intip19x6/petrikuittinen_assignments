x = 1
# print numbers from 1...10
while x<= 10:
    print(x)
    x += 1 # same as x = x+1
print("end")
  
