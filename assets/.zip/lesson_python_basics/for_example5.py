# range(begin, end, step)
# for iterates through a sequence
# 0, 3, 6, 9...30
for i in range(0, 31, 3):
    print(i)
    