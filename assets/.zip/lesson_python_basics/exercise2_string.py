s = input("Give me a string?")
print("Length of string:", len(s))
if s:
    print("First character:", s[0])
    print("Last character:", s[-1])
