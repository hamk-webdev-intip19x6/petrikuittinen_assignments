x = 1
# emulate do while with endless while and break
while True:
    print(x)
    x += 1
    if x>10: break
    