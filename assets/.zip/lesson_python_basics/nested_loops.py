N = 10
for y in range(1, N+1):
    for x in range(1, N+1):
        print("%3d " % (x*y), end="")
    print()
    

    