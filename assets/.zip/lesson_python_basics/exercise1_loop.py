for i in range(100, -2, -2):
    print(i)