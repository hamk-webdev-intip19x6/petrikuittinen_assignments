x = 0
for year in range(0, 17):
    x += 1200 # yearly deposit
    x *= 1.05 # interest
    print(x)
