# range(begin, end, step)
# for iterates through a sequence
for i in range(1, 11):
    print(i)
print("end")

a=5
a = 5
