print("ÄÖ öä")
