# range(begin, end, step)
# for iterates through a sequence
# 10..1
for i in range(10, 0, -1):
    print(i)
    