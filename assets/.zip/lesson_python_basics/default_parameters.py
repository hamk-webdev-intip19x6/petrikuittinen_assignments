def printMany(s, n=5):
    for i in range(n):
        print(s)
        
printMany("Hello", 3)
printMany("Five")
printMany(n=2, s="two")
