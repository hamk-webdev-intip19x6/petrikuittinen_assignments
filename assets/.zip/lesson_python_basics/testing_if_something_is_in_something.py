names = ["Jack", "Bob", "Bill"]
print("Jack" in names) # True
print("Jill" in names) # False
print("thing" in "It rains outside") # False
print("ins" in "It rains outside") # True



    