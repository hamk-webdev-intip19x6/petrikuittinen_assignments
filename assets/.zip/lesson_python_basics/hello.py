#!/usr/bin/python3
# you need to give execution rights to this file, using command line:
# chmod a+x filename
name = input("What is your name?")
print("Hello", name)
