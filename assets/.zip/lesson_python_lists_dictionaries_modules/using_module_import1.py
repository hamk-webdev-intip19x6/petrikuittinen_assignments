import myutil
# NOTICE: no .py needed here, just the part before .py
# and REMEMBER, only use a-z, 0-9 ._ in file or directory names, never use spaces etc.
# if you import like this each module has its own name space
# and must be prefixed like below
x = myutil.askFloat("Give me a float?")
print(x)
