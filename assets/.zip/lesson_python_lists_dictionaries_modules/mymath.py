def average(a):
    """return arithmetic mean of given list a of numbers"""
    return sum(a)/len(a)
    