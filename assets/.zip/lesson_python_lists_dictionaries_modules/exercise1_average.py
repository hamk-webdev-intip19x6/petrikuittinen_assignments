def average(a):
    return sum(a)/len(a)
    
def main():
    print(average([1, 2, 3]))
    print(average([10, 0, -5, 1]))
    
if __name__=='__main__':
    main()